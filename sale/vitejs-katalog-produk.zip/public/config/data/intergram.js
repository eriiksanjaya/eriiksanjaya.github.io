const intergram = {
  status: 1,
  label: {
    menu: "Chat",
    title: "Chat",
  },
  id: "yourID",
  mainColor: "#13283D",
  titleClosed: "",
  titleOpen: "Chat",
  introMessage: "Halo, selamat datang, ada yang bisa kami bantu?",
  autoResponse: "Mohon tunggu, sedang mencari admin yang sedang online.",
  autoNoResponse:
    "Sepertinya tidak ada yang bisa menjawab saat ini. Tolong beritahu kami bagaimana kami dapat menghubungi Anda, dan kami akan menghubungi Anda kembali sesegera mungkin.",
  alwaysUseFloatingButton: true,
};
