import { IconBell } from "../icons/IconBell";
import { IconCart } from "../icons/IconCart";
import { IconHome } from "../icons/IconHome";
import { IconStore } from "../icons/IconStore";
import { IconUser } from "../icons/IconUser";
import { ApiCart } from "../services/ApiCart";
import { ApiHome } from "../services/ApiHome";
import { ApiInfo } from "../services/ApiInfo";
import { ApiProfile } from "../services/ApiProfile";
import { ApiStore } from "../services/ApiStore";
import { ApiTheme } from "../services/ApiTheme";
import { totalQtyCart } from "../utils/CartProcess";
import { Inner } from "../utils/Inner";
import { Cart } from "./Cart";
import { Info } from "./Info";
import { Profile } from "./Profile";
import { Store } from "./Store";

globalThis.showHome = (title) => {
  document.title = title;
};

globalThis.showCartPage = () => {
  Inner(document.querySelector("#cart"), Cart(document.querySelector("#cart")));
};

globalThis.showProfilePage = () => {
  Inner(document.querySelector("#profile"), Profile());
};

globalThis.showStorePage = () => {
  Inner(document.querySelector("#store"), Store());
};

globalThis.showInfoPage = () => {
  Inner(document.querySelector("#info"), Info(document.querySelector("#info")));
};

globalThis.handleMenu = (event, tabId, color = [], title = null) => {
  if (title) {
    document.title = title;
  }

  const buttons = document.querySelectorAll(".menu-button");
  buttons.forEach((button) => {
    if (button.id === tabId) {
      button.classList.add("font-semibold");
      button.style.color = color[0];
    } else {
      button.classList.remove("font-semibold");
      button.style.color = color[1];
    }
  });
};

function displayTotalQtyCart() {
  const totalQty = totalQtyCart(); // Mendapatkan totalQtyCart

  if (totalQty) {
    const totalQtyDisplay = document.getElementById("totalQtyDisplay");
    if (totalQtyDisplay) {
      totalQtyDisplay.classList.remove("hidden");
      totalQtyDisplay.innerText = totalQty.toString();
    }
  } else {
    const totalQtyDisplay = document.getElementById("totalQtyDisplay");
    if (totalQtyDisplay) {
      totalQtyDisplay.classList.add("hidden");
    }
  }
}

// Memanggil displayTotalQtyCart untuk menampilkan jumlah awal
displayTotalQtyCart();

// Memanggil displayTotalQtyCart pada interval waktu tertentu (misalnya, setiap detik)
setInterval(() => {
  displayTotalQtyCart();
}, 1000);

export async function MenuBottom() {
  let gridCols = 5;

  const dataHome = await ApiHome();
  const dataInfo = await ApiInfo();
  const dataStore = await ApiStore();
  const dataCart = await ApiCart();
  const dataProfile = await ApiProfile();
  let theme = await ApiTheme();

  if (!dataInfo.status) {
    gridCols -= 1;
  }

  if (!dataStore.status) {
    gridCols -= 1;
  }

  if (!dataStore.status) {
    gridCols -= 1;
  }

  if (!dataProfile.status) {
    gridCols -= 1;
  }

  const store_up =
    dataStore.menu.position == "up" ? "-mt-6 rounded-full h-20 w-20" : "";

  let themeIndex = 0;
  let thMenuBottom = theme[themeIndex].menuBottom;

  let styleBg = `background-color: ${thMenuBottom.bg}; color: ${thMenuBottom.color}`;

  let styleStoreUp = "";
  if (dataStore.menu.position == "up") {
    styleStoreUp = `background-color: ${thMenuBottom.bg}; border: 3px solid ${thMenuBottom.activeColor}`;
  }

  return `
  <div class="fixed bottom-0 flex w-full md:w-[50%] xl:w-[35%]">
  <div style="${styleBg}" class="w-full h-20 grid grid-cols-${gridCols}">
    <button style="color: ${
      thMenuBottom.activeColor
    }" id="tab1" onclick="openTab('tab1', '${
    dataHome.label.menu
  }'); handleMenu(event, 'tab1', ['${thMenuBottom.activeColor}', '${
    thMenuBottom.color
  }'], '${dataHome.label.title}'); showHome('${
    dataHome.label.title
  }');" class="menu-button font-semibold relative w-full flex flex-col justify-center items-center space-y-1">
      <p id="" class="absolute"></p>
      ${IconHome(thMenuBottom.iconColor)}
    <p class="text-sm">${dataHome.label.menu}</p>
    </button>

    ${
      dataInfo.status
        ? `<button id="tab2" onclick="openTab('tab2'); handleMenu(event, 'tab2', ['${
            thMenuBottom.activeColor
          }', '${
            thMenuBottom.color
          }']); showInfoPage()" class="menu-button relative w-full flex flex-col justify-center items-center space-y-1">
    <p id="" class="absolute"></p>
    ${IconBell(thMenuBottom.iconColor)}
    <p class="text-sm">${dataInfo.label.menu}</p>
  </button>`
        : ""
    }
    

    ${
      dataStore.status
        ? `<button style="${styleStoreUp}" id="tab3" onclick="openTab('tab3'); handleMenu(event, 'tab3', ['${
            thMenuBottom.activeColor
          }', '${
            thMenuBottom.color
          }']); showStorePage()" class="menu-button relative flex flex-col justify-center items-center ${store_up} space-y-1">
        <p id="" class="absolute"></p>
        ${IconStore(thMenuBottom.iconColor)}
    <p class="text-sm">${dataStore.label.menu}</p>
      </button>`
        : ""
    }
    
    ${
      dataStore.status
        ? `<button id="tab4" onclick="openTab('tab4'); handleMenu(event, 'tab4', ['${
            thMenuBottom.activeColor
          }', '${
            thMenuBottom.color
          }']); showCartPage()" class="menu-button relative w-full flex flex-col justify-center items-center space-y-1">
    <div style="background-color: ${thMenuBottom.badge.bg}; color: ${
            thMenuBottom.badge.color
          }; font-weight: bold;" id="totalQtyDisplay" class="absolute top-2 right-3 lg:right-7 xl:right-5 2xl:right-7 w-4 h-4 rounded-full text-xs text-center"></div>
    ${IconCart(thMenuBottom.iconColor)}
    <p class="text-sm">${dataCart.label.menu}</p>
  </button>`
        : ""
    }
    
    
    ${
      dataProfile.status
        ? `<button id="tab5" onclick="openTab('tab5'); handleMenu(event, 'tab5', ['${
            thMenuBottom.activeColor
          }', '${
            thMenuBottom.color
          }']); showProfilePage()" class="menu-button relative w-full flex flex-col justify-center items-center space-y-1">
    <p id="" class="absolute"></p>
    ${IconUser(thMenuBottom.iconColor)}
    <p class="text-sm">${dataProfile.label.menu}</p>
  </button>`
        : ""
    }
    
  </div>
</div>
    `;
}
