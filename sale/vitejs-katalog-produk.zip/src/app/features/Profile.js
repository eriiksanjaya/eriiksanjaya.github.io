import { IconEmail } from "../icons/IconEmail";
import { IconMapPin } from "../icons/IconMapPin";
import { IconPhone } from "../icons/IconPhone";
import { IconUserCircle } from "../icons/IconUserCircle";
import { ApiProfile } from "../services/ApiProfile";
import { ApiTheme } from "../services/ApiTheme";
import { BaseUrl } from "../utils/BaseUrl";
import { fetchData } from "../utils/FetchData";
import { Version } from "../utils/Version";

export async function Profile() {
  let dataProfile = await ApiProfile();
  let theme = await ApiTheme();

  if (!dataProfile) return;

  document.title = dataProfile.label.title;

  let themeIndex = 0;
  let thCard = theme[themeIndex].card;
  let thProfile = theme[themeIndex].profile;
  let thHr = theme[themeIndex].horizontalLine;
  // console.log(data);

  let styleCard = `background-image: linear-gradient(${
    thCard.rotate
  }deg, ${thCard.bg.join()}); color: ${thCard.color}`;

  let styleHr = `border-bottom: 1px solid ${thHr.color}`;

  return `
    <div style="${styleCard}" class="w-full flex flex-col p-3 rounded-2xl">
      <div class="w-full flex flex-col space-y-3">
        <div class="w-full flex space-x-1 justify-start items-center">
            ${IconUserCircle(thProfile.title, "w-5 h-5")}
            <p style="color: ${thProfile.title}">${dataProfile.label.title}</p>
        </div>

        <div style="${styleHr}" class="w-full flex"></div>

        <div class="flex flex-col space-y-3 text-base w-full rounded-2xl">
          <div class="flex flex-col space-y-3">


            ${
              dataProfile.logo.status
                ? `<div class="w-full flex justify-center items-center">
                <img src="${dataProfile.logo.url}" alt="logo" class="hover:scale-105" style="width: ${dataProfile.logo.width}; height: ${dataProfile.logo.height}">
              </div>`
                : ``
            }
            
            <div class="text-secondary space-y-3">

              <p>${dataProfile.description}</p>

              ${
                dataProfile.telp.status
                  ? `<div class="flex space-x-3 items-center">
                ${IconPhone(thCard.color, "w-5 h-5 text-secondary")}
                <p>${dataProfile.telp.value}</p>
              </div>`
                  : ``
              }
              

              ${
                dataProfile.email.status
                  ? `<div class="flex space-x-3 items-center">
                ${IconEmail(thCard.color, "w-5 h-5 text-secondary")}
                <p>${dataProfile.email.value}</p>
              </div>`
                  : ``
              }

              ${
                dataProfile.address.status
                  ? `<div class="flex space-x-3 items-center">
                ${IconMapPin(thCard.color, "w-5 h-5 text-secondary")}
                <p>${dataProfile.address.value}</p>
              </div>`
                  : ``
              }
              
            </div>
          </div>
        </div>
        
        <div class="w-full flex flex-col justify-center items-end">
          <p class="text-xs px-3 py-1 rounded-xl shadow-xl shadow-amber-400/50 capitalize bg-amber-400 text-slate-800">${Version()}</p>
        </div>
      </div>
    </div>`;
}
