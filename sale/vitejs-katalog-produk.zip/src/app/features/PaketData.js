import { IconCard } from "../icons/IconCard";
import { IconGlobal } from "../icons/IconGlobal";
import { ApiDataPackage } from "../services/ApiDataPackage";
import { ApiTheme } from "../services/ApiTheme";
import { Currency } from "../utils/Currency";

export async function PaketData() {
  let dataPackage = await ApiDataPackage();
  let theme = await ApiTheme();

  if (!dataPackage) return;

  let themeIndex = 0;
  let thCard = theme[themeIndex].card;
  let thHr = theme[themeIndex].horizontalLine;
  let thButton = theme[themeIndex].button;
  let thDp = theme[themeIndex].dataPackage;

  let styleCard = `background-image: linear-gradient(${
    thCard.rotate
  }deg, ${thCard.bg.join()}); color: ${thCard.color}`;

  let styleBtn = `background-image: linear-gradient(${
    thButton.rotate
  }deg, ${thButton.bg.join()}); color: ${thButton.color}`;

  let styleHr = `border-bottom: 1px solid ${thHr.color}`;

  if (dataPackage.status) {
    return `
    <div style="${styleCard}" class="w-full flex flex-col p-3 rounded-2xl">
        <div class="w-full flex flex-col space-y-3">
            <div class="w-full flex space-x-1 justify-start items-center">
                ${IconCard(thDp.title, "w-5 h-5")}
                <p style="color: ${thDp.title}">${dataPackage.label.title}</p>
            </div>
            <div style="${styleHr}" class="w-full flex"></div>

            <div class="w-full xbg-red-500 flex flex-col space-y-3">
                
            ${(
              await Promise.all(
                dataPackage.data.map(async (val, index) => {
                  return `<div style="background-color: ${
                    val.bgColor
                  }; color: ${
                    val.color
                  };" class="w-full rounded-md shadow-md p-3 flex flex-col space-y-2">
                    <div class="text-sm w-full flex justify-between items-center">
                        <div class="w-full flex space-x-1 justify-start items-center">
                            ${IconGlobal(val.color, "w-5 h-5")}
                            <p class="">${val.name} ${val.description}</p>
                        </div>
                        <div class="w-max"><p class="font-semibold w-max">${await Currency(
                          val.price
                        )}</p></div>
                    </div>
                </div>`;
                })
              )
            ).join("")}
            
                
            </div>

            ${
              dataPackage.buttonOrder.status
                ? `<div style="${styleHr}" class="w-full flex"></div>

            <div>
                <a href="${dataPackage.buttonOrder.url}" class="w-full font-semibold text-center">
                <button style="${styleBtn}" type="button" class="flex p-3 rounded-full shadow-md w-full">
                <p class="w-full text-center">${dataPackage.buttonOrder.text}</p>
              </button>
                </a>
            </div>`
                : ""
            }
            
            
        </div>
    </div>`;
  }
}
