export function IconShieldWarning(color = null, className = "w-6 h-6") {
  let chgColor = "#1C274C";
  if (color) chgColor = color;
  let dom = `
    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="${className}">
      <path opacity="0.5" d="M3 10.4167C3 7.21907 3 5.62028 3.37752 5.08241C3.75503 4.54454 5.25832 4.02996 8.26491 3.00079L8.83772 2.80472C10.405 2.26824 11.1886 2 12 2C12.8114 2 13.595 2.26824 15.1623 2.80472L15.7351 3.00079C18.7417 4.02996 20.245 4.54454 20.6225 5.08241C21 5.62028 21 7.21907 21 10.4167C21 10.8996 21 11.4234 21 11.9914C21 17.6294 16.761 20.3655 14.1014 21.5273C13.38 21.8424 13.0193 22 12 22C10.9807 22 10.62 21.8424 9.89856 21.5273C7.23896 20.3655 3 17.6294 3 11.9914C3 11.4234 3 10.8996 3 10.4167Z" stroke="${chgColor}" stroke-width="1.5"/>
      <path d="M12 8V12" stroke="${chgColor}" stroke-width="1.5" stroke-linecap="round"/>
      <circle cx="12" cy="15" r="1" fill="${chgColor}"/>
    </svg>`;

  return dom;
}
