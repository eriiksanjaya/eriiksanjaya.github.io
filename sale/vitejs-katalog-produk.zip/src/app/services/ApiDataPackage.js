import { BaseUrl } from "../utils/BaseUrl";
import { fetchData } from "../utils/FetchData";

export const ApiDataPackage = async () => {
  const endpoint = "/config/data/dataPackage.json";
  try {
    return await fetchData(BaseUrl() + endpoint);
  } catch (error) {
    console.log(error);
  }
};
