import { BaseUrl } from "../utils/BaseUrl";
import { fetchData } from "../utils/FetchData";

export const ApiCurrency = async () => {
  const endpoint = "/config/data/currencyFormat.json";
  try {
    return await fetchData(BaseUrl() + endpoint);
  } catch (error) {
    console.log(error);
  }
};
