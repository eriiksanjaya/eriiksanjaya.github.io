import { BaseUrl } from "../utils/BaseUrl";

export const ApiIntergram = async () => {
  const endpoint = "/config/data/intergram.js";
  try {
    const response = await fetch(BaseUrl() + endpoint);
    if (!response.ok) {
      throw new Error(`Network response was not ok: ${response.status}`);
    }
    const jsCode = await response.text();
    // eval(jsCode);
    return intergram;
  } catch (error) {
    console.log(error);
  }
};
