import { BaseUrl } from "../utils/BaseUrl";
import { fetchData } from "../utils/FetchData";

export const ApiHome = async () => {
  const endpoint = "/config/data/home.json";
  try {
    return await fetchData(BaseUrl() + endpoint);
  } catch (error) {
    console.log(error);
  }
};
