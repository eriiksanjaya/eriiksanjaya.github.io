export async function Inner(element, data, type = "html") {
  if (element) {
    if (type == "html") {
      element.innerHTML = await data;
    } else {
      element.innerText = await data;
    }
  }
}
