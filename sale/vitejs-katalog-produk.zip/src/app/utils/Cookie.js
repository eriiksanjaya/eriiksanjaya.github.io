export function BaseUrl() {
  const baseUrl = window.location.href;
  const lastIndex = baseUrl.lastIndexOf("/");
  return baseUrl.substring(0, lastIndex);
}

// Fungsi untuk menambahkan atau mengubah cookie
export function CookieSet(name, value, days = 30) {
  const expirationDate = new Date();
  expirationDate.setDate(expirationDate.getDate() + days);
  const cookieValue = `${name}=${value}; expires=${expirationDate.toUTCString()}`;
  document.cookie = cookieValue;
}

// Fungsi untuk mendapatkan nilai cookie berdasarkan nama
export function CookieGet(name) {
  const cookies = document.cookie.split("; ");
  for (const cookie of cookies) {
    const [cookieName, cookieValue] = cookie.split("=");
    if (cookieName === name) {
      return cookieValue;
    }
  }
  return null; // Mengembalikan null jika cookie tidak ditemukan
}

// Fungsi untuk menghapus cookie berdasarkan nama
export function CookieDel(name) {
  document.cookie = `${name}=; expires=Thu, 01 Jan 1970 00:00:00 UTC`;
}
