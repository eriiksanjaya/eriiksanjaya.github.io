// vite.config.js
import legacy from "@vitejs/plugin-legacy";
import { resolve } from "path";
import { defineConfig } from "vite";

export default defineConfig({
  plugins: [
    // legacy({
    //   targets: ["defaults"],
    // }),
  ],
  build: {
    rollupOptions: {
      input: {
        main: resolve(__dirname, "index.html"),
      },
    },
  },
});
