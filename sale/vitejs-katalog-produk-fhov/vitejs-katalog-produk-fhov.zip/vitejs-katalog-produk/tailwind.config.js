/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./main.js",
    "./index.html",
    "./tailwindClass.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
};
