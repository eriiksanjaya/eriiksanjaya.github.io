import "./style.css";
import { Inner } from "./src/app/utils/Inner";
import { ImageSlider } from "./src/app/features/ImageSlider";
import { Navbar } from "./src/app/features/Navbar";
import { QuickMenu } from "./src/app/features/QuickMenu";
import { MenuBottom } from "./src/app/features/MenuBottom";
import { ApiTheme } from "./src/app/services/ApiTheme";
import { Diskon } from "./src/app/features/Diskon";
import { BuySourceCode } from "./src/app/features/BuySourceCode";

Inner(document.querySelector("#menuBottom"), MenuBottom());
Inner(document.querySelector("#quickMenu"), QuickMenu());
Inner(
  document.querySelector("#navbar"),
  Navbar(document.querySelector("#navbar"))
);

Inner(document.querySelector("#diskon"), Diskon());
Inner(document.querySelector("#buySourceCode"), BuySourceCode());

ImageSlider();

globalThis.openTab = (tabId, title = "") => {
  if (title) {
    document.title = title;
  }

  var tabs = document.getElementsByClassName("tab");
  for (var i = 0; i < tabs.length; i++) {
    tabs[i].style.display = "none";
  }
  document.getElementById(tabId).style.display = "block";
};

openTab("tab1");

const theme = async () => {
  let theme = await ApiTheme();

  let themeIndex = 0;
  let styleBg = theme[themeIndex].background;

  const body = document.body;
  body.style.backgroundImage = `linear-gradient(${
    styleBg.rotate
  }deg, ${styleBg.body.join()})`;

  const app = document.getElementById("app");
  if (app) {
    app.style.backgroundImage = `linear-gradient(${
      styleBg.rotate
    }deg, ${styleBg.container.join()})`;
  }

  // login
  let thCard = theme[themeIndex].card;
  const formCard = document.getElementById("formCard");
  if (formCard) {
    formCard.style.backgroundImage = `linear-gradient(${
      thCard.rotate
    }deg, ${thCard.bg.join()})`;
    formCard.style.color = `${thCard.color}`;
  }

  const globalCard = document.getElementById("globalCard");
  if (globalCard) {
    globalCard.style.backgroundImage = `linear-gradient(${
      thCard.rotate
    }deg, ${thCard.bg.join()})`;
    globalCard.style.color = `${thCard.color}`;
  }

  let thLogin = theme[themeIndex].login;
  const optionsLogin = document.getElementById("optionsLogin");
  if (optionsLogin) {
    optionsLogin.style.backgroundImage = `linear-gradient(${
      thLogin.option.rotate
    }deg, ${thLogin.option.bg.join()})`;
    optionsLogin.style.color = `${thLogin.option.color}`;
  }

  let thInput = theme[themeIndex].input;

  const inputLogins = document.querySelectorAll(".inputLogin");
  inputLogins.forEach((inputLogin) => {
    inputLogin.style.color = thInput.color;
    inputLogin.style.border = `1px solid ${thInput.border}`;

    inputLogin.addEventListener("click", () => {
      inputLogin.style.border = `1px solid ${thInput.activeBorder}`;
    });

    inputLogin.addEventListener("mouseleave", () => {
      inputLogin.style.border = `1px solid ${thInput.border}`;
    });
  });

  let thButton = theme[themeIndex].button;
  const btnLogin = document.getElementById("btnLogin");
  if (btnLogin) {
    btnLogin.style.backgroundImage = `linear-gradient(${
      thButton.rotate
    }deg, ${thButton.bg.join()})`;
    btnLogin.style.color = thButton.color;
  }

  const btnLogout = document.getElementById("btnLogout");
  if (btnLogout) {
    btnLogout.style.backgroundImage = `linear-gradient(${
      thButton.rotate
    }deg, ${thButton.bg.join()})`;
    btnLogout.style.color = thButton.color;
  }

  const hrs = document.querySelectorAll(".hr");
  hrs.forEach((hr) => {
    hr.style.borderBottom = `1px solid ${thInput.border}`;
  });
};

theme();

const countdownDiskon = () => {
  // countdown:
  var sekarang = new Date();
  // Tambahkan 1 jam ke tanggal dan waktu saat ini
  var satuJamKemudian = new Date(sekarang.getTime() + 60 * 60 * 1000);
  // Hitung selisih waktu antara sekarang dan satu jam ke depan
  var selisihWaktu = satuJamKemudian - sekarang;

  // var interval = setInterval(() => updateCountdown(selisihWaktu), 1000);

  // countdown:
  var sekarang = new Date();
  // Tambahkan 1 jam ke tanggal dan waktu saat ini
  var satuJamKemudian = new Date(sekarang.getTime() + 60 * 60 * 1000);
  // Hitung selisih waktu antara sekarang dan satu jam ke depan
  var selisihWaktu = satuJamKemudian - sekarang;

  // Update countdown setiap detik
  setInterval(() => {
    // Hitung jam, menit, dan detik dari selisih waktu
    var jam = Math.floor(selisihWaktu / (1000 * 60 * 60));
    var menit = Math.floor((selisihWaktu % (1000 * 60 * 60)) / (1000 * 60));
    var detik = Math.floor((selisihWaktu % (1000 * 60)) / 1000);

    const domCountdown = document.getElementById("countdownDiskon");

    // Tampilkan countdown pada elemen HTML
    if (domCountdown) {
      domCountdown.innerHTML = `${jam} : ${menit} : ${detik}`;
    } else {
      console.log("no dom");
    }

    // Kurangi selisih waktu dengan 1 detik
    selisihWaktu -= 1000;

    // Hentikan countdown jika sudah mencapai 0
    if (selisihWaktu < 0) {
      // clearInterval(interval);
      if (domCountdown) {
        domCountdown.innerHTML = "Waktu habis!";
      }
    }
  }, 1000);
};

countdownDiskon();
