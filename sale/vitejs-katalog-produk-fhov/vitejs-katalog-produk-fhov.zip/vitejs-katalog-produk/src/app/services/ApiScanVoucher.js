import { BaseUrl } from "../utils/BaseUrl";
import { fetchData } from "../utils/FetchData";

export const ApiScanVoucher = async () => {
  const endpoint = "/config/data/scanVoucher.json";
  try {
    return await fetchData(BaseUrl() + endpoint);
  } catch (error) {
    console.log(error);
  }
};
