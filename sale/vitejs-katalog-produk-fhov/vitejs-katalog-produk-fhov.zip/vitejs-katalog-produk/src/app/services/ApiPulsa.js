import { BaseUrl } from "../utils/BaseUrl";
import { fetchData } from "../utils/FetchData";

export const ApiPulsa = async () => {
  const endpoint = "/config/data/pulsa.json";
  try {
    return await fetchData(BaseUrl() + endpoint);
  } catch (error) {
    console.log(error);
  }
};
