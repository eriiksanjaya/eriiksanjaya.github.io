import { CookieGet, CookieSet } from "./Cookie";

export function getCart() {
  const cartCookie = CookieGet("cart");
  return cartCookie ? JSON.parse(cartCookie) : [];
}

// Fungsi untuk menyimpan keranjang belanja ke dalam cookie
export function saveCart(cart) {
  CookieSet("cart", JSON.stringify(cart));
}

// Fungsi untuk menambahkan produk ke dalam keranjang belanja dengan kuantitas (qty) tertentu
export function addToCart(index, qty) {
  const cart = getCart();

  // Cari apakah produk sudah ada di dalam keranjang
  const existingProduct = cart.find((item) => item.index === index);

  if (existingProduct) {
    // Jika produk sudah ada, tambahkan qty
    existingProduct.qty += qty;
  } else {
    // Jika produk belum ada, tambahkan produk baru ke dalam keranjang
    cart.push({
      index,
      qty,
    });
  }

  // Simpan kembali keranjang belanja yang sudah diperbarui ke dalam cookie
  saveCart(cart);
}

export function subtractCart(index, qty) {
  const cart = getCart();

  // Cari apakah produk sudah ada di dalam keranjang
  const existingProduct = cart.find((item) => item.index === index);

  if (existingProduct) {
    // Jika produk sudah ada, kurangkan qty (pastikan qty tidak negatif)
    existingProduct.qty -= qty;

    // Jika qty menjadi negatif, atur menjadi 0
    if (existingProduct.qty < 1) {
      existingProduct.qty = 1;
    }

    // Simpan kembali keranjang belanja yang sudah diperbarui ke dalam cookie
    saveCart(cart);
  }
}

// Fungsi untuk menghapus produk dari keranjang belanja berdasarkan indeks produk
export function removeCart(index) {
  const cart = getCart();

  // Temukan indeks produk yang akan dihapus
  const productIndex = cart.findIndex((item) => item.index === index);

  if (productIndex !== -1) {
    // Hapus produk dari keranjang jika ditemukan
    cart.splice(productIndex, 1);

    // Simpan kembali keranjang belanja yang sudah diperbarui ke dalam cookie
    saveCart(cart);
  }
}

export function totalQtyCart() {
  const cart = getCart(); // Mengambil keranjang belanja dari cookie
  let totalQty = 0;

  // Loop melalui setiap item dalam keranjang dan menghitung total kuantitas
  cart.forEach((item) => {
    totalQty += item.qty;
  });

  return totalQty;
}
