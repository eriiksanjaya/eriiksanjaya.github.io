import { ApiCurrency } from "../services/ApiCurrency";

export async function Currency(number = 0) {
  const currency = await ApiCurrency();

  if (!currency) return;

  const format = new Intl.NumberFormat(currency.localeCode, {
    style: "currency",
    currency: currency.currencyCode,
    minimumFractionDigits: currency.minimumFractionDigits,
  }).format(number);

  return format;
}
