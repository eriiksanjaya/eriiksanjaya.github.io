export function BaseUrl() {
  const baseUrl = window.location.href;
  const lastIndex = baseUrl.lastIndexOf("/");
  return baseUrl.substring(0, lastIndex);
}
