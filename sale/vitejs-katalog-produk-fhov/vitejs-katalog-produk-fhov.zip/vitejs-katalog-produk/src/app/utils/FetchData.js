export function fetchData(url, method = "GET", data = null) {
  const options = {
    method,
    headers: {
      "Content-Type": "application/json", // Ganti sesuai dengan jenis konten yang sesuai
      // Anda juga dapat menambahkan header lainnya jika diperlukan
    },
    // Mode dan credentials dapat diatur sesuai kebutuhan Anda
    mode: "no-cors", // atau 'no-cors' jika Anda tidak memerlukan CORS
    // credentials: "same-origin", // atau 'include' jika Anda memerlukan kredensial
  };

  if (data) {
    options.body = JSON.stringify(data);
  }

  return fetch(url, options)
    .then((response) => {
      if (!response.ok) {
        throw new Error(`Network response was not ok: ${response.status}`);
      }
      return response.json();
    })
    .catch((error) => {
      throw error;
    });
}
