export function IconScan(color = null, className = "w-6 h-6") {
  let chgColor = "#1C274C";
  if (color) chgColor = color;
  let dom = `
    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="${className}">
      <path opacity="0.5" d="M10 22C6.22876 22 4.34315 22 3.17157 20.8284C2 19.6569 2 18.7712 2 15" stroke="${chgColor}" stroke-width="1.5" stroke-linecap="round"/>
      <path opacity="0.5" d="M22 15C22 18.7712 22 19.6569 20.8284 20.8284C19.6569 22 17.7712 22 14 22" stroke="${chgColor}" stroke-width="1.5" stroke-linecap="round"/>
      <path opacity="0.5" d="M14 2C17.7712 2 19.6569 2 20.8284 3.17157C22 4.34315 22 5.22876 22 9" stroke="${chgColor}" stroke-width="1.5" stroke-linecap="round"/>
      <path opacity="0.5" d="M10 2C6.22876 2 4.34315 2 3.17157 3.17157C2 4.34315 2 5.22876 2 9" stroke="${chgColor}" stroke-width="1.5" stroke-linecap="round"/>
      <path d="M2 12H22" stroke="${chgColor}" stroke-width="1.5" stroke-linecap="round"/>
    </svg>`;

  return dom;
}
