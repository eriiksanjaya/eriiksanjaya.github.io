import { ApiNavbar } from "../services/ApiNavbar";
import { ApiTheme } from "../services/ApiTheme";

export async function Navbar(element) {
  let dataNavbar = await ApiNavbar();
  let theme = await ApiTheme();

  if (!dataNavbar) return;

  let themeIndex = 0;
  let thNavbar = theme[themeIndex].navbar;

  // console.log(thNavbar);

  const logo = dataNavbar.logo;
  const name = dataNavbar.name;
  const slogan = dataNavbar.slogan;

  if (dataNavbar.status) {
    let position = "justify-start";
    if (logo.position == "center") {
      position = "justify-center";
    }

    if (logo.position == "right") {
      position = "justify-end";
    }

    let stylebg = `background-image: linear-gradient(${
      thNavbar.bg.rotate
    }deg, ${thNavbar.bg.bgColor.join()});`;

    if (thNavbar.bg.backDropBlur) {
      stylebg = "";
    }

    return `
    <div id="childNavbar" style="${stylebg}" class="fixed top-0 z-10 backdrop-blur-lg px-5 py-2 flex w-full md:w-[50%] xl:w-[35%]">
        <div class="w-full flex justify-start items-center ">
            <div id="position" class="w-full flex ${position} ${
      name.status || slogan.status ? "space-x-3" : ""
    } items-center text-slate-800">
                ${
                  logo.status
                    ? `<img src="${logo.url}" alt="avatar" style="width: ${logo.width}; height: ${logo.height}" class="">`
                    : ``
                }
                <div>
                    ${
                      name.status
                        ? `<p style="color: ${thNavbar.title}" class="text-xl font-semibold">${name.text}</p>`
                        : ``
                    }
                    ${
                      slogan.status
                        ? `<p style="color: ${thNavbar.slogan}">${slogan.text}</p>`
                        : ``
                    }
                </div>
            </div>
        </div>
    </div>`;
  } else {
    element.remove();
    const app = document.getElementById("app");
    app.classList.remove("pt-16");
  }
}
