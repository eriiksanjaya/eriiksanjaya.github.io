import { IconVerifiedCheck } from "../icons/IconVerifiedCheck";
import { ApiInfo } from "../services/ApiInfo";
import { ApiTheme } from "../services/ApiTheme";

export async function Info() {
  let info = await ApiInfo();
  let theme = await ApiTheme();

  if (!info) return;

  document.title = info.label.title;

  let themeIndex = 0;
  let thAvatar = theme[themeIndex].avatar;
  let thCard = theme[themeIndex].card;
  let thInfo = theme[themeIndex].info;

  // let styleCard = `back: 3px solid ${thAvatar.ring}`;
  let styleCard = `background-image: linear-gradient(${
    thCard.rotate
  }deg, ${thCard.bg.join()}); color: ${thCard.color}`;

  let styleBorder = `border: 3px solid ${thAvatar.ring}`;

  if (info.status) {
    return `
    <div class="w-full flex flex-col space-y-3">
        <div style="color: ${thInfo.title}" class="font-semibold">${
      info.label.title
    }</div>
        <div class="w-full flex flex-col space-y-3">

            ${info.data
              .map((val, index) => {
                return `<div class="w-full flex flex-col space-y-3">
                <div style="${styleCard}" class="w-full flex flex-col p-3 space-y-3 rounded-md">
                <div class="w-full flex space-x-3 justify-start items-center">
                    <img src="${
                      val.imageUrl
                    }" alt="avatar" style="${styleBorder}" class="w-10 h-10 md:w-12 md:h-12 rounded-full">
                    <div class="w-full flex space-x-1 justify-start items-center font-semibold"><p>${
                      val.name
                    }</p> ${IconVerifiedCheck("#3b82f6", "w-4 h-4")}</div>
                </div>
                <div>
                    <p>${val.description}</p>
                </div>
                </div>
            </div>`;
              })
              .join("")}

        
        </div>
    </div>`;
  } else {
    return `<div class="h-[20rem]"></div>`;
  }
}
