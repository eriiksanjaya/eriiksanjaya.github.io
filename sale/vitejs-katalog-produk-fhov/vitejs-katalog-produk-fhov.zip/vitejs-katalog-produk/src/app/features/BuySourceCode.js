import { IconCard } from "../icons/IconCard";
import { ApiTheme } from "../services/ApiTheme";
import { Version } from "../utils/Version";

globalThis.handleBuy = () => {
  window.location.href =
    "https://eriksanjaya.mayar.link/catalog/source-code-katalog-produk-dengan-vitejs-html-vanilla-js-dan-tailwind-css";
};

export async function BuySourceCode() {
  let theme = await ApiTheme();

  if (!theme) return;

  let themeIndex = 0;
  let thCard = theme[themeIndex].card;
  let thProfile = theme[themeIndex].profile;
  let thHr = theme[themeIndex].horizontalLine;

  let styleCard = `background-image: linear-gradient(${
    thCard.rotate
  }deg, ${thCard.bg.join()}); color: ${thCard.color}`;

  let styleHr = `border-bottom: 1px solid ${thHr.color}`;

  let thButton = theme[themeIndex].button;

  let styleBtn = `background-image: linear-gradient(${
    thButton.rotate
  }deg, ${thButton.bg.join()}); color: ${thButton.color}`;

  return `
    <div style="${styleCard}" class="w-full flex flex-col p-3 rounded-2xl">
      <div class="w-full flex flex-col space-y-3">
        <div class="w-full flex space-x-1 justify-start items-center">
            ${IconCard(thProfile.title, "w-5 h-5")}
            <p style="color: ${thProfile.title}">Beli Source Code</p>
        </div>

        <div style="${styleHr}" class="w-full flex"></div>

        <div class="flex flex-col space-y-3 text-base w-full rounded-2xl">
          <div class="flex flex-col space-y-3">

            <p>Ingin beli source code ini?</p>

            <button style="${styleBtn}" type="button" onclick="handleBuy()" class="bg-blue-900 flex p-3 rounded-full shadow-md w-full">
              <p class="w-full font-semibold text-center">Beli sekarang!</p>
            </button>


          </div>
        </div>
        
      </div>
    </div>`;
}
