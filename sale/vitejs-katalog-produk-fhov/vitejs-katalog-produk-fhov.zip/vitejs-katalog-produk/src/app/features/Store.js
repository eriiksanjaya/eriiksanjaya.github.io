import { IconCart } from "../icons/IconCart";
import { ApiStore } from "../services/ApiStore";
import { ApiTheme } from "../services/ApiTheme";
import { addToCart } from "../utils/CartProcess";
import { Currency } from "../utils/Currency";

globalThis.add = (index, qty) => {
  addToCart(index, qty);
};

export async function Store() {
  let store = await ApiStore();
  let theme = await ApiTheme();

  if (!store) return;

  document.title = store.label.title;

  let themeIndex = 0;
  let thCard = theme[themeIndex].card;
  let thStore = theme[themeIndex].store;
  let thButton = theme[themeIndex].button;

  let styleCard = `background-image: linear-gradient(${
    thCard.rotate
  }deg, ${thCard.bg.join()}); color: ${thCard.color}`;

  let styleBtn = `background-image: linear-gradient(${
    thButton.rotate
  }deg, ${thButton.bg.join()}); color: ${thButton.color}`;

  if (store.status) {
    return `
      <div class="w-full flex flex-col space-y-3">
        <div style="color: ${thStore.title}" class="font-semibold">${
      store.label.title
    }</div>
        <div class="w-full grid grid-cols-2 gap-3">

        ${(
          await Promise.all(
            store.data.map(async (val, index) => {
              return `<div style="${styleCard}" class="w-full flex flex-col rounded-md shadow-md xbg-white h-full justify-between">
            <img src="${
              val.imageUrl
            }" alt="icon" class="w-full rounded-t-md rounded-b-xl shadow-xl mb-1 shadow-slate-700/50">
            <div class="p-3 h-full">
              <div class="w-full flex flex-col space-y-3 h-full justify-between items-center">
                <div class="w-full justify-start h-min flex flex-col text-left">
                  <p class="">${val.name}</p>
                  <p class="w-full font-semibold flex text-left">${await Currency(
                    val.price
                  )}</p>
                </div>
                <button style="${styleBtn}" onclick="add(
                  ${index},
                  1
                )" class="px-3 py-1 flex space-x-1 rounded-md shadow-md">
                  <div class="w-full flex space-x-1 justify-center items-center">
                    ${IconCart(thButton.color, "w-5 h-5")}
                    <p class="text-sm">${store.label.button.addToCart}</p>
                  </div>
                </button>
              </div>
            </div>
          </div>`;
            })
          )
        ).join("")}

        </div>
      </div>`;
  }
}
