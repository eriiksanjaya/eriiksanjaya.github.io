import Siema from "siema";
import { fetchData } from "../utils/FetchData";
import { BaseUrl } from "../utils/BaseUrl";

// const slides = ["slide-1.webp", "slide-2.webp", "slide-1.webp", "slide-2.webp"];

const api = async () => {
  const imageSlider_enp = "/config/data/imageSlider.json";
  try {
    const imageSlider = await fetchData(BaseUrl() + imageSlider_enp);
    return {
      imageSlider,
    };
  } catch (error) {
    console.log(error);
  }
};

export async function ImageSlider() {
  let getdata = await api();

  if (!getdata) return;

  const dt_imageSlider = getdata.imageSlider;
  // console.log(dt_imageSlider);
  const data = dt_imageSlider.data;

  if (dt_imageSlider.status) {
    const domSlider = document.querySelector("#slider");
    let dom = `
    <div class="p-5 w-full overflow-hidden">
      <div class="siema w-full">
      `;
    data.forEach((item) => {
      dom += `<img src="${item.url}" class="rounded-md w-max" />`;
    });

    dom += `
      </div>
    </div>
  `;

    if (domSlider) {
      domSlider.innerHTML = dom;

      const mySiema = new Siema({
        selector: ".siema",
        duration: 200,
        easing: "ease-in",
        perPage: 1,
        startIndex: 0,
        draggable: true,
        multipleDrag: true,
        threshold: 20,
        loop: true,
        rtl: false,
        onInit: () => {},
        onChange: () => {},
      });

      setInterval(() => mySiema.next(), dt_imageSlider.delay * 1000);
    }
  }
}

// Panggil fungsi untuk menginisialisasi Swiper
