import { IconChat } from "../icons/IconChat";
import { ApiDataPackage } from "../services/ApiDataPackage";
import { ApiScanVoucher } from "../services/ApiScanVoucher";
import { ApiIntergram } from "../services/ApiIntergram";
import { PaketData } from "./PaketData";
import { Inner } from "../utils/Inner";
import { IconScan } from "../icons/IconScan";
import { ApiTheme } from "../services/ApiTheme";
import { Pulsa } from "./Pulsa";
import { ApiPulsa } from "../services/ApiPulsa";
import { IconDataPackage } from "../icons/IconDataPakcage";
import { IconPulsa } from "../icons/IconPulsa";

globalThis.showDataPackagePage = () => {
  Inner(document.querySelector("#paketData"), PaketData());
};

globalThis.showPulsaPage = () => {
  Inner(document.querySelector("#paketData"), Pulsa());
};

globalThis.openChat = () => {
  document.dispatchEvent(new CustomEvent("chatToggled", { detail: true }));

  const childNavbar = document.getElementById("childNavbar");

  var windowWidth = window.innerWidth;
  if (windowWidth <= 499) {
    if (childNavbar) {
      childNavbar.classList.remove("fixed");
      childNavbar.classList.remove("top-0");
      childNavbar.classList.remove("z-10");
    }
  }
};

export async function QuickMenu() {
  let pulsa = await ApiPulsa();
  let dataPackage = await ApiDataPackage();
  let scanVoucher = await ApiScanVoucher();
  let intergram = await ApiIntergram();
  let theme = await ApiTheme();

  if (!dataPackage) return;

  let themeIndex = 0;
  let styleQuick = theme[themeIndex].quickMenu;

  let styleBg = `background-image: linear-gradient(${
    styleQuick.rotate
  }deg, ${styleQuick.bgIcon.join()});`;

  let styleColor = `color: ${styleQuick.color}`;

  return `
    <div class="w-full flex flex-col px-5 space-y-3">
          <div class="w-full flex flex-col space-y-3">
            <div class="w-full grid grid-cols-4 gap-3">
    
            ${
              pulsa.status
                ? `<div onclick="openTab('tab6'); showPulsaPage()" class="w-full flex flex-col space-y-3 justify-center items-center text-center cursor-pointer">
            <div style="${styleBg}" class="flex justify-center items-center w-16 h-16 p-3 rounded-full">
              ${IconPulsa(styleQuick.iconColor, "w-12 h-12")}
            </div>
            <p style="${styleColor}" class="w-max text-sm text-center">${
                    pulsa.label.menu
                  }</p>
        </div>`
                : ``
            }
            
            ${
              dataPackage.status
                ? `<div onclick="openTab('tab6'); showDataPackagePage()" class="w-full flex flex-col space-y-3 justify-center items-center text-center cursor-pointer">
            <div style="${styleBg}" class="flex justify-center items-center w-16 h-16 p-3 rounded-full">
              ${IconDataPackage(styleQuick.iconColor, "w-12 h-12")}
            </div>
            <p style="${styleColor}" class="w-max text-sm text-center">${
                    dataPackage.label.menu
                  }</p>
        </div>`
                : ``
            }

            
            

                ${
                  scanVoucher.status
                    ? `<a href="${
                        scanVoucher.url
                      }"><div class="w-full flex flex-col space-y-3 justify-center items-center text-center">
                <div style="${styleBg}" class="flex justify-center items-center w-16 h-16 p-3 rounded-full">
                  ${IconScan(styleQuick.iconColor, "w-12 h-12")}
                  </div>
               <p style="${styleColor}" class="w-max text-sm text-center">${
                        scanVoucher.label.menu
                      }</p>
            </div></a>`
                    : ``
                }
    
                ${
                  intergram.status
                    ? `<div id="openChated" onclick="openChat()" class="w-full flex flex-col space-y-3 justify-center items-center text-center cursor-pointer">
                <div style="${styleBg}" class="flex justify-center items-center w-16 h-16 p-3 rounded-full">
                  ${IconChat(styleQuick.iconColor, "w-12 h-12")}
                </div>
                <p style="${styleColor}" class="w-max text-sm text-center">${
                        intergram.label.menu
                      }</p>
            </div>`
                    : ``
                }
            </div>
          </div>
      </div>`;
}
