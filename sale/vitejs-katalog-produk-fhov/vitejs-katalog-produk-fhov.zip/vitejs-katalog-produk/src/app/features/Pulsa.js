import { IconCard } from "../icons/IconCard";
import { IconGlobal } from "../icons/IconGlobal";
import { ApiPulsa } from "../services/ApiPulsa";
import { ApiTheme } from "../services/ApiTheme";
import { Currency } from "../utils/Currency";

export async function Pulsa() {
  let pulsa = await ApiPulsa();
  let theme = await ApiTheme();

  if (!pulsa) return;

  let themeIndex = 0;
  let thCard = theme[themeIndex].card;
  let thHr = theme[themeIndex].horizontalLine;
  let thButton = theme[themeIndex].button;
  let thP = theme[themeIndex].pulsa;

  let styleCard = `background-image: linear-gradient(${
    thCard.rotate
  }deg, ${thCard.bg.join()}); color: ${thCard.color}`;

  let styleBtn = `background-image: linear-gradient(${
    thButton.rotate
  }deg, ${thButton.bg.join()}); color: ${thButton.color}`;

  let styleHr = `border-bottom: 1px solid ${thHr.color}`;

  if (pulsa.status) {
    return `
    <div style="${styleCard}" class="w-full flex flex-col p-3 rounded-2xl">
        <div class="w-full flex flex-col space-y-3">
            <div class="w-full flex space-x-1 justify-start items-center">
                ${IconCard(thP.title, "w-5 h-5")}
                <p style="color: ${thP.title}">${pulsa.label.title}</p>
            </div>
            <div style="${styleHr}" class="w-full flex"></div>

            <div class="w-full xbg-red-500 flex flex-col space-y-3">
                
            ${(
              await Promise.all(
                pulsa.data.map(async (val, index) => {
                  return `<div style="background-color: ${
                    val.bgColor
                  }; color: ${
                    val.color
                  };" class="w-full rounded-md shadow-md p-3 flex flex-col space-y-2">
                    <div class="text-sm w-full flex justify-between items-center">
                        <div class="w-full flex space-x-1 justify-start items-center">
                            ${IconGlobal(val.color, "w-5 h-5")}
                            <p class="">${val.name} ${val.description}</p>
                        </div>
                        <div class="w-max"><p class="font-semibold w-max">${await Currency(
                          val.price
                        )}</p></div>
                    </div>
                </div>`;
                })
              )
            ).join("")}
            
                
            </div>

            ${
              pulsa.buttonOrder.status
                ? `<div style="${styleHr}" class="w-full flex"></div>

            <div>
                <a href="${pulsa.buttonOrder.url}" class="w-full font-semibold text-center">
                <button style="${styleBtn}" type="button" class="flex p-3 rounded-full shadow-md w-full">
                <p class="w-full text-center">${pulsa.buttonOrder.text}</p>
              </button>
                </a>
            </div>`
                : ""
            }
            
            
        </div>
    </div>`;
  }
}
