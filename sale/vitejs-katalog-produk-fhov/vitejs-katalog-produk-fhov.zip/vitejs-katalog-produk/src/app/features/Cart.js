import { IconCart } from "../icons/IconCart";
import { IconShieldWarning } from "../icons/IconShieldWarning";
import { IconTrash } from "../icons/IconTrash";
import { ApiCart } from "../services/ApiCart";
import { ApiStore } from "../services/ApiStore";
import { ApiTheme } from "../services/ApiTheme";
import {
  addToCart,
  getCart,
  removeCart,
  subtractCart,
} from "../utils/CartProcess";
import { CookieGet, CookieSet } from "../utils/Cookie";
import { Currency } from "../utils/Currency";
import { Inner } from "../utils/Inner";

// Fungsi untuk mengambil data dari cookie cart (jika ada)
function getCartData() {
  const cartCookie = CookieGet("cart");
  return cartCookie ? JSON.parse(cartCookie) : [];
}

// Fungsi untuk menggabungkan data dari store.json dan data dari cookie cart
async function mergeStoreAndCartData() {
  const storeData = await ApiStore();
  const cartData = getCartData();

  // Filter hanya produk yang ada dalam keranjang
  const cartIndices = cartData.map((cartItem) => cartItem.index);

  // Loop melalui data toko (storeData) dan tambahkan informasi kuantitas dari cartData
  const mergedData = storeData.data.filter((product, index) => {
    if (cartIndices.includes(index)) {
      const cartProduct = cartData.find((cartItem) => cartItem.index === index);
      if (cartProduct) {
        product.qty = cartProduct.qty;
        product.index = index; // Menambahkan atribut 'index' ke objek produk
      } else {
        product.qty = 0;
      }
      return true;
    }
    return false;
  });

  return mergedData;
}

const showCartPage = () => {
  Inner(document.querySelector("#cart"), Cart(document.querySelector("#cart")));
};

globalThis.remove_cart = (index) => {
  removeCart(index);
  showCartPage();
};

globalThis.add_cart = (index, qty) => {
  addToCart(index, qty);
  showCartPage();
};

globalThis.subtract_cart = (index, qty) => {
  subtractCart(index, qty);
  showCartPage();
};

globalThis.calculateTotalPrice = (cart) => {
  let totalPrice = 0;

  for (const product of cart) {
    const price = parseFloat(product.price);
    const qty = product.qty;
    totalPrice += price * qty;
  }

  return totalPrice;
};

globalThis.handleSubmit = async () => {
  let dataCart = await ApiCart();

  const alert = document.getElementById("alert");
  const nama = document.getElementById("nama");
  const catatan = document.getElementById("catatan");

  if (nama.value == "") {
    alert.classList.remove("hidden");
    alert.classList.add("flex");
    alert.innerHTML = `${IconShieldWarning()} <p>${
      dataCart.label.alert.name
    }</p>`;
    nama.focus();
    return false;
  } else {
    alert.classList.remove("flex");
    alert.classList.add("hidden");
  }

  if (catatan.value == "") catatan.value = "-";

  CookieSet("buyer_name", nama.value);
  CookieSet("buyer_catatan", catatan.value);

  const cart = await mergeStoreAndCartData().then((data) => {
    return data;
  });

  // const totalHarga = calculateTotalPrice(cart);

  // let msg = `*Data Pembeli:*\nNama: ${nama.value}\nCatatan: ${catatan.value}\n\n*Data Order:*\n`;
  // cart.map(async (val, index) => {
  //   const formattedPrice = await Currency(val.price);

  //   msg += `${val.name}\n  ${val.qty} x ${formattedPrice}\n`;
  // });
  // msg += `\nTotal Harga:\n*${await Currency(totalHarga)}*`;

  // window.open(
  //   `${dataCart.buttonOrder.url}/?text=${encodeURIComponent(msg)}`,
  //   "_blank"
  // );

  const totalHarga = calculateTotalPrice(cart);

  let msg = `*Data Pembeli:*\nNama: ${nama.value}\nCatatan: ${catatan.value}\n\n*Data Order:*\n`;

  // Menggunakan Promise.all untuk menunggu semua operasi asinkron selesai
  const formattedItems = await Promise.all(
    cart.map(async (val, index) => {
      const formattedPrice = await Currency(val.price);
      return `${val.name}\n  ${val.qty} x ${formattedPrice}\n`;
    })
  );

  msg += formattedItems.join("");
  msg += `\nTotal Harga:\n*${await Currency(totalHarga)}*`;

  window.open(
    `${dataCart.buttonOrder.url}/?text=${encodeURIComponent(msg)}`,
    "_blank"
  );
};

globalThis.changeStyle = (element, color, border) => {
  element.style.color = color;
  element.style.border = border;
};

export async function Cart(element) {
  let get_cart = getCart();
  let cart = await ApiCart();
  let theme = await ApiTheme();

  if (!get_cart) return;

  document.title = cart.label.title;

  const getDataCart = await mergeStoreAndCartData().then((mergedData) => {
    return mergedData;
  });

  const totalHarga = calculateTotalPrice(getDataCart);

  let buyer_name =
    CookieGet("buyer_name") != null ? CookieGet("buyer_name") : "";
  let buyer_catatan =
    CookieGet("buyer_catatan") != null ? CookieGet("buyer_catatan") : "";

  let themeIndex = 0;
  let thCard = theme[themeIndex].card;
  let thHr = theme[themeIndex].horizontalLine;
  let thButton = theme[themeIndex].button;
  let thCart = theme[themeIndex].cart;

  let styleCard = `background-image: linear-gradient(${
    thCard.rotate
  }deg, ${thCard.bg.join()}); color: ${thCard.color}`;

  let styleHr = `border-bottom: 1px solid ${thHr.color}`;

  let styleBtn = `background-image: linear-gradient(${
    thButton.rotate
  }deg, ${thButton.bg.join()}); color: ${thButton.color}`;

  let thInput = theme[themeIndex].input;

  let styleInput = `color: ${thInput.color};`;

  const inputLogins = document.querySelectorAll(".inputLogin");
  inputLogins.forEach((inputLogin) => {
    inputLogin.style.color = thInput.color;
    inputLogin.style.border = `1px solid ${thInput.border}`;

    inputLogin.addEventListener("click", () => {
      inputLogin.style.color = thInput.activeColor;
      inputLogin.style.border = `1px solid ${thInput.activeBorder}`;
    });

    inputLogin.addEventListener("mouseleave", () => {
      inputLogin.style.border = `1px solid ${thInput.border}`;
    });
  });

  if (get_cart.length) {
    return `
  <div style="${styleCard}" class="w-full flex flex-col p-3 bg-white rounded-2xl">
    <div class="w-full flex flex-col space-y-3">
        <div class="w-full flex space-x-1 justify-start items-center">
            ${IconCart(thCart.title, "w-5 h-5")}
            <p style="color: ${thCart.title}">${cart.label.title}</p>
        </div>
        <div style="${styleHr}" class="w-full flex"></div>

        <div class="w-full flex flex-col space-y-3">
        
          <div class="w-full flex flex-col space-y-2">

          ${(
            await Promise.all(
              getDataCart.map(async (val, index) => {
                const formattedPrice = await Currency(val.price);
                return `
                <div class="w-full flex space-x-3">
                  <img src="${
                    val.imageUrl
                  }" alt="icon" class="w-16 h-16 rounded-t-md rounded-b-md shadow-xl shadow-slate-700/50" />
                  <div class="p-3 w-full">
                    <div class="w-full flex flex-col h-full justify-start">
                      <div class="w-full justify-start h-min flex flex-col text-left">
                        <p class="font-semibold">${val.name}</p>
                        <p class="w-full flex text-left">${
                          val.qty
                        } x ${formattedPrice}</p>
                      </div>
          
                      <div class="w-full flex space-x-3 justify-end items-center">
                        <button class="" onclick="remove_cart(${val.index})">
                          ${IconTrash(thCart.icon.trash)}
                        </button>
                        <div style="border: 1px solid ${
                          thInput.border
                        }" class="w-max flex justify-start items-center rounded-md px-3">
                          <button style="color: ${
                            thCart.button.subtract
                          }" onclick="subtract_cart(${
                  val.index
                }, 1)" class="text-xl">-</button>
                          <input type="text" value="${
                            val.qty
                          }" class="flex w-8 text-center outline-none readonly bg-transparent" readonly>
                          <button style="color: ${
                            thCart.button.add
                          }" onclick="add_cart(${
                  val.index
                }, 1)" class="text-xl">+</button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div style="${styleHr}" class="w-full flex"></div>
              `;
              })
            )
          ).join("")}

            <div>
              <p>${cart.label.totalPrice}</p>
              <p class="font-semibold">${await Currency(totalHarga)}</p>
            </div>

            <div style="${styleHr}" class="w-full flex"></div>
            
            <div class="w-full flex flex-col space-y-1">
              <p>${cart.label.buyyerData.title}</p>
              <div class="w-full flex flex-col space-y-3">
                <div class="space-y-1">
                  <label for="nama" class="capitalize text-primary">${
                    cart.label.buyyerData.name
                  }</label>
                  <input 
                  style="${styleInput}; border: 1px solid ${thInput.border}" 
                  onclick="changeStyle(this, '${thInput.color}', '1px solid ${
      thInput.activeBorder
    }');"
                  onmouseout="changeStyle(this, '${
                    thInput.color
                  }', '1px solid ${thInput.border}');"
                  type="text" id="nama" name="nama" value="${buyer_name}" placeholder="${
      cart.label.buyyerData.name
    }" autocomplete="off" class="inputs autofill:bg-transparent p-3 rounded-md bg-transparent outline-none w-full">
                </div>

                <div class="space-y-1">
                  <label for="catatan" class="capitalize text-primary">${
                    cart.label.buyyerData.note
                  }</label>
                  <textarea 
                  style="${styleInput}; border: 1px solid ${thInput.border}" 
                  onclick="changeStyle(this, '${thInput.color}', '1px solid ${
      thInput.activeBorder
    }');"
                  onmouseout="changeStyle(this, '${
                    thInput.color
                  }', '1px solid ${thInput.border}');"
                  id="catatan" name="catatan" placeholder="${
                    cart.label.buyyerData.note
                  }" autocomplete="off" class="inputs autofill:bg-transparent p-3 rounded-md bg-transparent outline-none w-full">${buyer_catatan}</textarea>
                </div>

                <div id="alert" class="hidden w-full justify-start items-center space-x-3 text-slate-700 space-y-1 p-3 rounded-md shadow-md bg-amber-400"></div>

                <button style="${styleBtn}" type="button" onclick="handleSubmit()" class="bg-blue-900 flex p-3 rounded-full shadow-md w-full">
                  <p class="w-full font-semibold text-center">${
                    cart.buttonOrder.text
                  }</p>
                </button>
                
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>`;
  } else {
    return `<div style="${styleCard}" class="w-full flex flex-col p-3 rounded-2xl">
    <div class="w-full flex flex-col space-y-3">
        <div class="w-full flex space-x-1 justify-start items-center">
        ${IconCart(thCart.title, "w-5 h-5")}
        <p style="color: ${thCart.title}">${cart.label.title}</p>
        </div>
        <div style="${styleHr}" class="w-full flex"></div>

        <div class="w-full flex flex-col space-y-3 min-h-[20rem]">
        
          <div class="w-full flex flex-col space-y-2">
          </div>
          </div>
          </div>
          </div>
          `;
  }
}
