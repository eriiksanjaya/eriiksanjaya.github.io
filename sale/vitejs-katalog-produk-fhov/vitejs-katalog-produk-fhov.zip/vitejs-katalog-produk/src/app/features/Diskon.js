import { IconCart } from "../icons/IconCart";
import { ApiStore } from "../services/ApiStore";
import { ApiTheme } from "../services/ApiTheme";
import { addToCart, removeCart, subtractCart } from "../utils/CartProcess";
import { Currency } from "../utils/Currency";
import { Inner } from "../utils/Inner";
import { Cart } from "./Cart";
import { Store } from "./Store";

const showCartPage = () => {
  Inner(document.querySelector("#cart"), Cart(document.querySelector("#cart")));
};

globalThis.showStorePage = () => {
  Inner(document.querySelector("#store"), Store());
};

globalThis.remove_cart = (index) => {
  removeCart(index);
  showCartPage();
};

globalThis.add_cart = (index, qty) => {
  addToCart(index, qty);
  showCartPage();
};

globalThis.subtract_cart = (index, qty) => {
  subtractCart(index, qty);
  showCartPage();
};

globalThis.calculateTotalPrice = (cart) => {
  let totalPrice = 0;

  for (const product of cart) {
    const price = parseFloat(product.price);
    const qty = product.qty;
    totalPrice += price * qty;
  }

  return totalPrice;
};

globalThis.handleMenu = (event, tabId, title) => {
  if (title) {
    document.title = title;
  }

  const buttons = document.querySelectorAll(".menu-button");
  buttons.forEach((button) => {
    if (button.id === tabId) {
      button.classList.add("font-semibold");
      // button.style.color = color[0];
    } else {
      button.classList.remove("font-semibold");
      // button.style.color = color[1];
    }
  });
};

globalThis.changeStyle = (element, color, border) => {
  element.style.color = color;
  element.style.border = border;
};

globalThis.add = (index, qty) => {
  addToCart(index, qty);
};

export async function Diskon(element) {
  let store = await ApiStore();
  let theme = await ApiTheme();

  if (!store) return;

  let themeIndex = 0;
  let thCard = theme[themeIndex].card;
  let thButton = theme[themeIndex].button;

  let styleCard = `background-image: linear-gradient(${
    thCard.rotate
  }deg, ${thCard.bg.join()}); color: ${thCard.color}`;

  let styleBtn = `background-image: linear-gradient(${
    thButton.rotate
  }deg, ${thButton.bg.join()}); color: ${thButton.color}`;

  return `
  <div  style="${styleCard}" class="w-full flex flex-col p-3 space-y-2 rounded-2xl">
  <div class="w-full flex justify-between  items-end">
  <div>
    <p class="font-semibold">Kejar Diskon Spesial</p>
    <div class="w-full flex space-x-3">
      <p class="text-sm">Berakhir dalam</p>
      <div id="countdownDiskon" class="px-2 text-white text-xs flex items-center bg-rose-600 rounded-full">00 : 00 : 23</div>
    </div>
  </div>
  <button type="button" onclick="openTab('tab3'); handleMenu(event, 'tab3'); showStorePage()" class="cursor-pointer text-xs text-green-500 font-semibold">Lihat Semua</button>
</div>

<div class="flex w-full">
  <div class="p-3 w-full bg-slate-200 rounded-md flex space-x-3 overflow-x-scroll">

    ${(
      await Promise.all(
        store.data.map(async (val, index) => {
          return `<div class="flex flex-col rounded-md shadow-md bg-white">
      <img src="${val.imageUrl}" alt="icon" class="w-full p-3 rounded-2xl">
      <div class="px-3 pb-3">
        <div class="w-full flex flex-col space-y-3 justify-between items-center">
          <div class="w-full justify-start h-min flex flex-col text-left">
            <p class="w-full font-semibold flex text-left">${await Currency(
              val.price
            )}</p>
            <div class="w-full flex space-x-1">
              <p class="w-max font-semibold flex text-left text-slate-500 text-xs line-through">Rp&nbsp;120.000</p>
              <p class="text-xs text-red-500 font-semibold">33%</p>
            </div>
            <div class="pt-3 space-y-1">
              <div class="w-full bg-slate-300 rounded-full">
                <div class="w-[80%] p-[0.11rem] bg-rose-500 rounded-full"></div>
              </div>
              <p class="text-xs text-rose-500">Segera habis</p>
              <button style="${styleBtn}" onclick="add(
                ${index},
                1
              )" class="px-3 py-1 flex space-x-1 rounded-md shadow-md">
                <div class="w-full flex space-x-1 justify-center items-center">
                  ${IconCart(thButton.color, "w-5 h-5")}
                  <p class="text-sm w-max">${store.label.button.addToCart}</p>
                </div>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>`;
        })
      )
    ).join("")}
    
  </div>
</div>
  </div>`;
}
