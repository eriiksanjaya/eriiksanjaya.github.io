<style>
    .imam-body {
        font-size: 23px !important;
    }

    .ptgsJumat {
        font-size: 23px !important;
    }
</style>

<div class="row ws-container">
    <div class="col-md-2 col-lg-2 col-xl-2 padding-0">
        <div class="waktu-shalat-b">
            <div class="waktu-shalat bg-slate-700 mx-1 my-1 border-b-8 border-teal-600 z-depth-1 text-center">
                <h2>Terbit</h2>
                <h1 class="text-white"><?php echo substr(jadwal_shalat()['terbit'], 0, 5); ?></h1>
            </div>
        </div>
    </div>
    <div class="col-md-2 col-lg-2 col-xl-2 padding-0">
        <div class="waktu-shalat-b">
            <div class="waktu-shalat bg-slate-700 mx-1 my-1 border-b-8 border-blue-500 darken-3 unique z-depth-1 text-center">
                <h2>Subuh</h2>
                <h1 class="text-white"><?php echo substr(jadwal_shalat()['subuh'], 0, 5); ?></h1>
            </div>
        </div>
    </div>

    <div class="col-md-2 col-lg-2 col-xl-2 padding-0">
        <div class="waktu-shalat-b">
            <div class="waktu-shalat bg-slate-700 mx-1 my-1 border-b-8 border-yellow-500 darken-1 z-depth-1 text-center">
                <h2>Dzuhur</h2>
                <h1 class="text-white"><?php echo substr(jadwal_shalat()['dzuhur'], 0, 5); ?></h1>
            </div>
        </div>
    </div>
    <div class="col-md-2 col-lg-2 col-xl-2 padding-0">
        <div class="waktu-shalat-b">
            <div class="waktu-shalat bg-slate-700 mx-1 my-1 border-b-8 border-indigo-600 darken-3 z-depth-1 text-center">
                <h2>Ashar</h2>
                <h1 class="text-white"><?php echo substr(jadwal_shalat()['ashar'], 0, 5); ?></h1>
            </div>
        </div>
    </div>

    <div class="col-md-2 col-lg-2 col-xl-2 padding-0">
        <div class="waktu-shalat-b">
            <div class="waktu-shalat bg-slate-700 mx-1 my-1 border-b-8 border-red-600 darken-3 z-depth-1 text-center">
                <h2>Maghrib</h2>
                <h1 class="text-white"><?php echo substr(jadwal_shalat()['maghrib'], 0, 5); ?></h1>
            </div>
        </div>
    </div>

    <div class="col-md-2 col-lg-2 col-xl-2 padding-0">
        <div class="waktu-shalat-b">
            <div class="waktu-shalat bg-slate-700 mx-1 my-1 border-b-8 border-sky-600 darken-3 z-depth-1 text-center">
                <h2>Isya</h2>
                <h1 class="text-white"><?php echo substr(jadwal_shalat()['isya'], 0, 5); ?></h1>
            </div>
        </div>
    </div>

    <div class="z-50 row running-text w-full">
        <div class="col-md-12 col-lg-12 col-xl-12">
            <marquee>
                <div class="flex space-x-3 items-center py-2">
                    <?php echo (get_running_text()['status']) ? get_running_text()['data'] : ""; ?>
                </div>
            </marquee>
        </div>
    </div>
</div>

<script>
    $(function() {
        var hari = moment().format('dddd');

        // if (hari == "Minggu" || hari == "Senin" || hari == "Selasa" || hari == "Rabu" || hari == "Kamis" || hari == "Jumat" || hari == "Sabtu") {
        //     localStorage.setItem("tipe", "jumat");
        //     localStorage.setItem("time", moment().unix() + 20);
        //     setInterval(check_storage, 1000);
        //     // fs_jumat();
        //     hari_jumat();
        //     $('.fs-jumat').slideDown('slow');
        // } else {
        //     fs_general();
        //     $('.fs-jumat').slideUp('slow');
        // }

    });
</script>