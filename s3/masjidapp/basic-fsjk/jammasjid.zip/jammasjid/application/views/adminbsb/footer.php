<footer id="footer" class="pt-2 text-center page-footer text-md-left" style="bottom: 0; left: 0; right: 0; position: fixed;">
    <!--Copyright-->
    <div class="py-2 text-center footer-copyright">
        <div class="container-fluid">
            &copy 2018 <?php echo (date("Y") == "2018") ? "" : " - " . date("Y"); ?> <a href="https://eriksanjaya.com">eriksanjaya.com</a>
        </div>
    </div>
    <!--/.Copyright-->
</footer>
<!--/.Footer-->