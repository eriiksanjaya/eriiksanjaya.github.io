<div class="card">
	<div class="card-body">
		<h3 class="teal-text"><?php echo $message; ?></h3>
	</div>
</div>