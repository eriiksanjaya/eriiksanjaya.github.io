<?php echo @$content; ?>

<script type="text/javascript">
    $(function(){
        // MyApp.init();
    });
</script>
