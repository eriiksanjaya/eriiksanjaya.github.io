<div class="row ws-container">
    <div class="col-md-2 col-lg-2 col-xl-2 padding-0">
        <div class="waktu-shalat-b">
            <div class="waktu-shalat bg-terbit z-depth-1 text-center">
                <h2>Terbit</h2>
                <h1 style="color: white;"><?php echo substr(jadwal_shalat()['terbit'], 0, 5); ?></h1>
            </div>
        </div>
    </div>
    <div class="col-md-2 col-lg-2 col-xl-2 padding-0">
        <div class="waktu-shalat-b">
            <div class="waktu-shalat bg-subuh darken-3 unique z-depth-1 text-center">
                <h2>Subuh</h2>
                <h1 style="color: white;"><?php echo substr(jadwal_shalat()['subuh'], 0, 5); ?></h1>
            </div>
        </div>
    </div>
    <div class="col-md-2 col-lg-2 col-xl-2 padding-0">
        <div class="waktu-shalat-b">
            <div class="waktu-shalat bg-dzuhur darken-1 z-depth-1 text-center">
                <h2>Dzuhur</h2>
                <h1 style="color: white;"><?php echo substr(jadwal_shalat()['dzuhur'], 0, 5); ?></h1>
            </div>
        </div>
    </div>
    <div class="col-md-2 col-lg-2 col-xl-2 padding-0">
        <div class="waktu-shalat-b">
            <div class="waktu-shalat bg-ashar darken-3 z-depth-1 text-center">
                <h2>Ashar</h2>
                <h1 style="color: white;"><?php echo substr(jadwal_shalat()['ashar'], 0, 5); ?></h1>
            </div>
        </div>
    </div>
    <div class="col-md-2 col-lg-2 col-xl-2 padding-0">
        <div class="waktu-shalat-b">
            <div class="waktu-shalat bg-maghrib darken-3 z-depth-1 text-center">
                <h2>Maghrib</h2>
                <h1 style="color: white;"><?php echo substr(jadwal_shalat()['maghrib'], 0, 5); ?></h1>
            </div>
        </div>
    </div>
    <div class="col-md-2 col-lg-2 col-xl-2 padding-0">
        <div class="waktu-shalat-b">
            <div class="waktu-shalat bg-isya darken-3 z-depth-1 text-center">
                <h2>Isya</h2>
                <h1 style="color: white;"><?php echo substr(jadwal_shalat()['isya'], 0, 5); ?></h1>
            </div>
        </div>
    </div>

    <div class="z-50 row running-text w-full">
        <div class="col-md-12 col-lg-12 col-xl-12">
            <marquee>
                <div class="flex space-x-3 items-center py-2">
                    <?php echo (get_running_text()['status']) ? get_running_text()['data'] : ""; ?>
                </div>
            </marquee>
        </div>
    </div>
</div>

<script>
    $(function() {
        var hari = moment().format('dddd');

        if (hari == "Minggu" || hari == "Senin" || hari == "Selasa" || hari == "Rabu" || hari == "Kamis" || hari == "Jumat" || hari == "Sabtu") {
            localStorage.setItem("tipe", "jumat");
            localStorage.setItem("time", moment().unix() + 20);
            setInterval(check_storage, 1000);
            // fs_jumat();
            // hari_jumat();
            // $('.fs-jumat').slideDown('slow');
            fs_general();
        } else {
            fs_general();
            // imam_hari_ini();
            // $('.fs-jumat').slideUp('slow');
        }

        function check_storage() {

            var tipe = localStorage.getItem("tipe");
            var time = localStorage.getItem("time");

            var now = moment().unix();

            if (tipe == "jumat" && now > time) {
                localStorage.setItem("tipe", "imam");
                var newtime = moment().unix() + 20;
                localStorage.setItem("time", newtime);
            } else if (tipe == "imam" && now > time) {
                localStorage.setItem("tipe", "jumat");
                var newtime = moment().unix() + 20;
                localStorage.setItem("time", newtime);
            } else {}
        }

        function fs_jumat() {}

        function fs_general() {}

    });
</script>