<div class="row clearfix">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="card px-3 py-3 space-y-1">

            <div class="flex space-x-3 px-3 py-3">
                <h1 class="text-3xl">Pilih Tema :</h1>
            </div>

            <div id="tema" class="flex flex-wrap gap-3 px-3 py-3">
                <button onclick="thUpdate('0');" class="w-fit px-3 py-3 rounded-md shadow-md <?php echo $tema == '1' ? 'bg-indigo-500 text-white' : 'bg-slate-300 text-slate-500' ?>">
                    <p class="">Tema 1</p>
                </button>

                <button onclick="thUpdate('1');" class="w-fit px-3 py-3 rounded-md shadow-md <?php echo $tema == '2' ? 'bg-indigo-500 text-white' : 'bg-slate-300 text-slate-500' ?>">
                    <p class="">Tema 2</p>
                </button>

                <button onclick="thUpdate('2');" class="w-fit px-3 py-3 rounded-md shadow-md <?php echo $tema == '3' ? 'bg-indigo-500 text-white' : 'bg-slate-300 text-slate-500' ?>">
                    <p class="">Tema 3</p>
                </button>

                <button onclick="thUpdate('3');" class="w-fit px-3 py-3 rounded-md shadow-md <?php echo $tema == '4' ? 'bg-indigo-500 text-white' : 'bg-slate-300 text-slate-500' ?>">
                    <p class="">Tema 4</p>
                </button>

                <button onclick="thUpdate('4');" class="w-fit px-3 py-3 rounded-md shadow-md <?php echo $tema == '5' ? 'bg-indigo-500 text-white' : 'bg-slate-300 text-slate-500' ?>">
                    <p class="">Tema 5</p>
                </button>

                <button onclick="thUpdate('5');" class="w-fit px-3 py-3 rounded-md shadow-md <?php echo $tema == '6' ? 'bg-indigo-500 text-white' : 'bg-slate-300 text-slate-500' ?>">
                    <p class="">Tema 6</p>
                </button>
            </div>

        </div>
    </div>
</div>

<script>
    const thUpdate = (val) => {
        const url = '<?php echo base_url(); ?>pengaturan/tema/update_tema';
        const data = {
            tema: val,
        };
        const formData = new FormData();
        formData.append('tema', val);
        const options = {
            method: 'POST',
            body: formData,
        };
        fetch(url, options)
            .then(response => {
                return response.json();
            })
            .then(data => {
                if (data.status) {
                    window.location.href = window.location.href
                }
            })
            .catch(error => {
                console.error('Kesalahan:', error);
            });
    }
</script>